g++ -I/usr/local/cuda/include/ -shared -fPIC clblas.cpp -o libclblas.so
