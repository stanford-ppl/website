g++ -I$JAVA_HOME/include -I$JAVA_HOME/include/linux -shared -fPIC openclInit.cpp -o openclInit.so
