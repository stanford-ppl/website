package ppl.delite.framework.datastruct.scala.container;

public interface Comparator {
	int compare(int o1, int o2);
}